== ATtami panelized ==
gerber files for 4x4 panel (10x10cm)

panel processed using gerbv[1] python script

from CAM job made via eagle PCB
use gerbv to view gerber file[3]


contact yair99@gmail.com


[1] http://174.136.57.11/~ruggedci/gerbmerge/ [offline], there a re a few githubs but i use this
[3] http://gerbv.sourceforge.net/